/**
 * @file   Namespace.h
 * @author Yibo Lin
 * @date   Jan 2019
 */

#ifndef DREAMPLACE_UTILITY_NAMESPACE_H
#define DREAMPLACE_UTILITY_NAMESPACE_H

#define DREAMPLACE_NAMESPACE DreamPlace
#define DREAMPLACE_BEGIN_NAMESPACE namespace DreamPlace {
#define DREAMPLACE_END_NAMESPACE }

#endif
